import { isURL, isWhatsAppURL } from '../../lib/Utilities.js'

export default {
   command: 'afk',
   category: 'user info',
   async run(m, {
      text,
      user
   }) {
      if (isURL(text) || isWhatsAppURL(text))
         return m.reply('❌ You can\'t set a link as your AFK reason.')
      user.afkReason = text
      user.afkContext = m
      user.afkTimestamp = user.lastSeen
      await m.reply(`🏷️ @${m.sender.split('@')[0]} is now AFK.`)
   }
}