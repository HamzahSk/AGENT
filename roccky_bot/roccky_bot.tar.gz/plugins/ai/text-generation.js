import { nexray } from '../../lib/Request.js'

export default {
   command: ['ai', 'claude', 'copilot', 'deepsearch', 'deepseek', 'dgaf', 'dolphin', 'dreamanalyze', 'gita', 'glm', 'hammer', 'nexray', 'perplexity'],
   category: 'ai',
   async run(m, {
      sock,
      isPrefix,
      command,
      text
   }) {
      try {
         if (!text)
            return m.reply(`👉🏻 *Example*: ${isPrefix + command} hello`)
         await m.react('🕒')
         const path =
            command === 'ai' ?
               'chatgpt' :
               command === 'gita' ?
                  'gitagpt' :
                  command
         const params = { text }
         if (command === 'dolphin')
            params.template = 'logical'
         if (command === 'glm')
            params.model = 'glm-4.6'
         if (command === 'hammer')
            params.model = 'Sleepy'
         const data = await nexray('ai/' + path, params)
         if (!data.status)
            return m.reply('❌ Failed to get data.')
         await m.reply(data.result)
      }
      catch (error) {
         console.error(error)
         await m.reply('❌ ' + error.message)
      }
   },
   limit: 1
}