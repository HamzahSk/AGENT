export default {
   command: ['setlabel', 'dellabel'],
   category: 'owner',
   async run(m, {
      sock,
      isPrefix,
      command,
      text
   }) {
      if (command === 'setlabel') {
         if (!text)
            return m.reply(`👉🏻 *Example*: ${isPrefix + command} WhatsApp bot`)
         if (text.length > 30)
            return m.reply('❌ Maximum 30 characters.')
         await sock.updateMemberLabel(m.chat, text)
         await m.reply('✅ Successfully set member label for bot.')
      }
      else if (command === 'dellabel') {
         await sock.updateMemberLabel(m.chat, '')
         await m.reply('✅ Successfully delete member label for bot.')
      }
   },
   owner: true,
   group: true
}